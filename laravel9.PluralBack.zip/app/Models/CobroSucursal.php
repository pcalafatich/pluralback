<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CobroSucursal extends Model
{
    use HasFactory;

    protected $table = 'cobro_sucursales';

    protected $guarded = [];

    //RELACIONES

}


